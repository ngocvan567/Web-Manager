document.addEventListener('DOMContentLoaded', () => {
    // Handle Register Form
    const regForm = document.getElementById('registerForm');
    if (regForm) {
        regForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const pass = document.getElementById('password').value;
            const confirmPass = document.getElementById('confirmPassword').value;

            if (pass !== confirmPass) {
                alert('Mật khẩu xác nhận không khớp!');
                return;
            }

            const body = {
                mssv: document.getElementById('mssv').value.trim(),
                full_name: document.getElementById('fullName').value.trim(),
                email: document.getElementById('email').value.trim(),
                course: document.getElementById('course').value.trim(),
                password: pass
            };

            const res = await API.request('/api/register', { method: 'POST', body: JSON.stringify(body) });
            if (res.status === 'success') {
                alert(res.message);
                window.location.href = '/login';
            }
        });
    }

    // Handle Login Form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const body = {
                account: document.getElementById('account').value.trim(),
                password: document.getElementById('password').value.trim()
            };

            const res = await API.request('/api/login', { method: 'POST', body: JSON.stringify(body) });
            if (res.status === 'success') {
                if (res.user.role === 'ADMIN') {
                    window.location.href = '/admin/dashboard';
                } else {
                    window.location.href = '/member/dashboard';
                }
            }
        });
    }
});

async function logout() {
    await API.request('/api/logout', { method: 'POST' });
    window.location.href = '/login';
}
