const API = {
    async request(url, options = {}) {
        options.headers = { 'Content-Type': 'application/json', ...options.headers };
        try {
            const response = await fetch(url, options);
            const data = await response.json();
            if (!response.ok) {
                if (response.status === 401) {
                    window.location.href = '/login';
                }
                throw new Error(data.message || 'Lỗi kết nối máy chủ');
            }
            return data;
        } catch (err) {
            alert(err.message);
            throw err;
        }
    }
};
