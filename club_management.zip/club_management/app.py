import os
from functools import wraps
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_mysqldb import MySQL
import MySQLdb.cursors

app = Flask(__name__)
app.secret_key = 'super_secret_club_management_key'

# MySQL Database Configuration
app.config['MYSQL_HOST'] = os.environ.get('MYSQL_HOST', 'localhost')
app.config['MYSQL_USER'] = os.environ.get('MYSQL_USER', 'root')
app.config['MYSQL_PASSWORD'] = os.environ.get('MYSQL_PASSWORD', '')
app.config['MYSQL_DB'] = os.environ.get('MYSQL_DB', 'club_management')
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)

# ---------------------------------------------------------
# RBAC MIDDLEWARES
# ---------------------------------------------------------
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return jsonify({'status': 'error', 'message': 'Chưa đăng nhập. Vui lòng đăng nhập lại.'}), 401
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session or session['user']['role'] != 'ADMIN':
            return jsonify({'status': 'error', 'message': 'Từ chối truy cập! Quyền ADMIN mới được phép thực hiện.'}), 403
        return f(*args, **kwargs)
    return decorated_function

# ---------------------------------------------------------
# HTML PAGE ROUTES
# ---------------------------------------------------------
@app.route('/')
def index():
    if 'user' in session:
        if session['user']['role'] == 'ADMIN':
            return redirect('/admin/dashboard')
        return redirect('/member/dashboard')
    return redirect('/login')

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/register')
def register_page():
    return render_template('register.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'user' not in session or session['user']['role'] != 'ADMIN':
        return redirect('/login')
    return render_template('admin/dashboard.html')

@app.route('/member/dashboard')
def member_dashboard():
    if 'user' not in session or session['user']['role'] != 'MEMBER':
        return redirect('/login')
    return render_template('member/dashboard.html')

# ---------------------------------------------------------
# RESTFUL APIS
# ---------------------------------------------------------

# 1. Register API
@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.json or {}
    mssv = data.get('mssv', '').strip()
    full_name = data.get('full_name', '').strip()
    email = data.get('email', '').strip()
    password = data.get('password', '').strip()
    course = data.get('course', 'K19').strip()

    if not mssv or not email or not password or not full_name:
        return jsonify({'status': 'error', 'message': 'Vui lòng nhập đầy đủ các thông tin bắt buộc.'}), 400

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id FROM users WHERE mssv = %s OR email = %s", (mssv, email))
    existing = cursor.fetchone()
    if existing:
        cursor.close()
        return jsonify({'status': 'error', 'message': 'MSSV hoặc Email đã được sử dụng trong hệ thống.'}), 400

    # Auto assign role = MEMBER, status = ACTIVE
    cursor.execute("""
        INSERT INTO users (mssv, username, password, full_name, email, role, status)
        VALUES (%s, %s, %s, %s, %s, 'MEMBER', 'ACTIVE')
    """, (mssv, mssv, password, full_name, email))
    user_id = cursor.lastrowid

    # Create Member record assigned to default department_id = 1 (Không có ban)
    cursor.execute("""
        INSERT INTO members (user_id, student_code, full_name, email, course, department_id, position)
        VALUES (%s, %s, %s, %s, %s, 1, 'Thành Viên')
    """, (user_id, mssv, full_name, email, course))

    mysql.connection.commit()
    cursor.close()

    return jsonify({'status': 'success', 'message': 'Đăng ký tài khoản thành công! Tự động cấp quyền MEMBER.'}), 201

# 2. Login API
@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.json or {}
    account = data.get('account', '').strip()
    password = data.get('password', '').strip()

    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT u.id, u.mssv, u.full_name, u.email, u.password, u.role, u.status,
               m.department_id, d.department_name, m.position
        FROM users u
        LEFT JOIN members m ON u.id = m.user_id
        LEFT JOIN departments d ON m.department_id = d.department_id
        WHERE u.mssv = %s OR u.email = %s OR u.username = %s
    """, (account, account, account))
    user = cursor.fetchone()
    cursor.close()

    if not user or user['password'] != password:
        return jsonify({'status': 'error', 'message': 'MSSV/Email hoặc mật khẩu không chính xác.'}), 400

    if user['status'] != 'ACTIVE':
        return jsonify({'status': 'error', 'message': 'Tài khoản hiện đang bị khóa hoặc ngừng hoạt động.'}), 403

    user_payload = {
        'id': user['id'],
        'mssv': user['mssv'],
        'name': user['full_name'],
        'email': user['email'],
        'role': user['role'],
        'department_id': user['department_id'],
        'department_name': user['department_name'] or 'Không có ban',
        'position': user['position'] or 'Thành Viên'
    }

    session['user'] = user_payload
    return jsonify({'status': 'success', 'user': user_payload}), 200

# 3. Logout API
@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.pop('user', None)
    return jsonify({'status': 'success', 'message': 'Đã đăng xuất thành công.'}), 200

# 4. User Info API
@app.route('/api/me', methods=['GET'])
@login_required
def get_me():
    user_id = session['user']['id']
    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT u.id, u.mssv, u.full_name, u.email, u.role, u.status,
               m.course, m.position, d.department_id, d.department_name
        FROM users u
        LEFT JOIN members m ON u.id = m.user_id
        LEFT JOIN departments d ON m.department_id = d.department_id
        WHERE u.id = %s
    """, (user_id,))
    user_info = cursor.fetchone()
    cursor.close()
    return jsonify({'status': 'success', 'user': user_info})

# 5. Get Users List API (ADMIN)
@app.route('/api/users', methods=['GET'])
@admin_required
def get_users():
    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT u.id, u.mssv, u.full_name, u.email, u.role, u.status, m.department_id, d.department_name, m.position
        FROM users u
        LEFT JOIN members m ON u.id = m.user_id
        LEFT JOIN departments d ON m.department_id = d.department_id
        ORDER BY u.id ASC
    """)
    users = cursor.fetchall()
    cursor.close()
    return jsonify({'status': 'success', 'data': users})

# 6. Change Role API (ADMIN)
@app.route('/api/users/<int:user_id>/role', methods=['PUT'])
@admin_required
def change_role(user_id):
    data = request.json or {}
    new_role = data.get('role')
    if new_role not in ['ADMIN', 'MEMBER']:
        return jsonify({'status': 'error', 'message': 'Role không hợp lệ.'}), 400

    cursor = mysql.connection.cursor()
    cursor.execute("UPDATE users SET role = %s WHERE id = %s", (new_role, user_id))
    mysql.connection.commit()
    cursor.close()
    return jsonify({'status': 'success', 'message': f'Đã cập nhật role thành {new_role} thành công.'})

# 7. Change Status API (ADMIN)
@app.route('/api/users/<int:user_id>/status', methods=['PUT'])
@admin_required
def change_status(user_id):
    data = request.json or {}
    new_status = data.get('status')
    if new_status not in ['ACTIVE', 'BLOCKED']:
        return jsonify({'status': 'error', 'message': 'Trạng thái không hợp lệ.'}), 400

    cursor = mysql.connection.cursor()
    cursor.execute("UPDATE users SET status = %s WHERE id = %s", (new_status, user_id))
    mysql.connection.commit()
    cursor.close()
    return jsonify({'status': 'success', 'message': 'Cập nhật trạng thái tài khoản thành công.'})

# 8. Change Member Department API (ADMIN)
@app.route('/api/members/<int:user_id>/department', methods=['PUT'])
@admin_required
def change_member_dept(user_id):
    data = request.json or {}
    dept_id = data.get('department_id')

    cursor = mysql.connection.cursor()
    cursor.execute("UPDATE members SET department_id = %s WHERE user_id = %s", (dept_id, user_id))
    mysql.connection.commit()
    cursor.close()
    return jsonify({'status': 'success', 'message': 'Đã chuyển ban cho thành viên thành công!'})

# 9. Departments List API
@app.route('/api/departments', methods=['GET'])
@login_required
def get_departments():
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM departments")
    depts = cursor.fetchall()
    cursor.close()
    return jsonify({'status': 'success', 'data': depts})

# 10. Events API
@app.route('/api/events', methods=['GET', 'POST'])
@login_required
def handle_events():
    cursor = mysql.connection.cursor()
    if request.method == 'GET':
        cursor.execute("SELECT * FROM events ORDER BY start_time DESC")
        events = cursor.fetchall()
        cursor.close()
        return jsonify({'status': 'success', 'data': events})

    if request.method == 'POST':
        if session['user']['role'] != 'ADMIN':
            return jsonify({'status': 'error', 'message': 'Từ chối truy cập.'}), 403
        data = request.json or {}
        cursor.execute("""
            INSERT INTO events (title, description, location, start_time, end_time, host_by)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (data['title'], data['description'], data['location'], data['start_time'], data['end_time'], session['user']['id']))
        mysql.connection.commit()
        cursor.close()
        return jsonify({'status': 'success', 'message': 'Tạo sự kiện mới thành công.'})

# 11. Announcements API
@app.route('/api/announcements', methods=['GET'])
@login_required
def get_announcements():
    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT a.*, u.full_name as author_name
        FROM announcements a
        LEFT JOIN users u ON a.created_by = u.id
        WHERE a.status = 'Đã đăng'
        ORDER BY a.publish_date DESC
    """)
    anns = cursor.fetchall()
    cursor.close()
    return jsonify({'status': 'success', 'data': anns})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
